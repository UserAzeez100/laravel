<?php

namespace App\Http\Controllers;

use App\Models\School;
use App\Models\Teacher;
use Dotenv\Validator;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;
use Illuminate\Http\Response ;
use Illuminate\Support\Facades\Http;

class SchoolController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $school = new School();
       $data =  $school->with('teachers')->get();

       $data =$school->with(['teachers',function($query){
    $query->where('age','>',25);
       }])->get();
       
       $school = $school->has('teacher','>','2')->with('teacher')->withCount('teacher')->get();

       //------------
        return response()->json(["status"=>$data!=null, "massage"=> $data!=null ?
         "success":"failed","data"=>$data],$data!=null ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST);
    }

   
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatror =Validator($request->all(),[
            'name'=> 'required|String|min:3|max:25',
            //image::::::::::::::::::::::::::::::::::::::
            "image"=>"required|image"

        ]);
        if(!$validatror->fails()){
       
        $school =new School();
        $school ->name =$request->input("name");

        //image::::
        $image=$request->file("image");
        $new_image="product_".time().".".$image->getClientOriginalExtension();
        $image->move(public_path("upload"),$new_image);
        $school->image=$new_image;

        $status =$school->save();
        
        return response()->json(["sataus"=> $status,"massage"=>"good","object"=>$school],$status ?Response::HTTP_OK:Response::HTTP_BAD_REQUEST );

        }
        return response()->json(["sataus"=> false,"massage"=>$validatror->getMessageBag()->first()],Response::HTTP_BAD_REQUEST);


    }

    /**
     * Display the specified resource.
     */
    public function show(School $school)
    {

     $data =School::find($school->id);

     return response()->json(["status"=>$data!=null, "massage"=> $data!=null ?
     "success":"failed","data"=>$data],$data!=null ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, School $school)
    {
        $validatror =Validator($request->all(),[
            'name'=> 'required|String|min:3|max:25',
        ]);
        if(!$validatror->fails()){
       
        $school =School::find($school->id);
        $school ->name =$request->input("name");

        $status =$school->save();
        
        return response()->json(["sataus"=> $status,"massage"=>"good","object"=>$school],$status ?Response::HTTP_OK:Response::HTTP_BAD_REQUEST );

        }
        return response()->json(["sataus"=> false,"massage"=>$validatror->getMessageBag()->first()],Response::HTTP_BAD_REQUEST);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(School $school)
    {
        //
        $school =School::find($school->id);
        $dataDeleted =$school ->delete(); 

        return response()->json(["status"=>$dataDeleted!=null, "massage"=> $dataDeleted!=null ?
        "success":"failed","data"=>$dataDeleted],$dataDeleted!=null ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST);

    }
}
